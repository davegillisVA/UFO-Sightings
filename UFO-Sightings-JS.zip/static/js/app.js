var tbody = d3.select("tbody");
renderTable(data);

let datetime = document.querySelector('#datetime');
let shape = document.querySelector('#shape');
let country = document.querySelector('#country');
let state = document.querySelector('#state');
let city = document.querySelector('#city');
// var tableData = data;
// https://github.com/jamesa820
//https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select  
//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter 
//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/every??
//https://stackoverflow.com/questions/53639365/filter-an-array-of-objects-with-multiple-criteria-and-partial-matches

// console.log(data);
// this function populates the table from data as an initial load
// and also from a slected set of filtered records called sightings
function renderTable(tableData){
  
  tableData.forEach(function(reportSightings) {
    // console.log(reportSightings);
    var row = tbody.append("tr");

    Object.entries(reportSightings).forEach(function([key, value]){
      // console.log(key, value);

      var cell = row.append("td");
      cell.text(value);
          });
  });

}
// Create pulldown lists for query selection
function buildFormOptions(tableData) {
  // Get all unique values of each column.

  // Possible refactor.
  // let dataPoints = [
  //   [],
  //   [],
  // ]

  let dates = [];
  let shapes = [];
  let countries = [];
  let states = [];
  let cities = [];

  tableData.forEach(function(sighting) {
    dates.push(sighting.datetime);
    shapes.push(sighting.shape);
    countries.push(sighting.country);
    states.push(sighting.state);
    cities.push(sighting.city);
  });
  //// build unique value set for each pulldown list to build query
  dates = dates.filter(function(value, index, self) {
    return self.indexOf(value) === index;
  });
  shapes = shapes.filter(function(value, index, self) {
    return self.indexOf(value) === index;
  });
  countries = countries.filter(function(value, index, self) {
    return self.indexOf(value) === index;
  });
  states = states.filter(function(value, index, self) {
    return self.indexOf(value) === index;
  });
  cities = cities.filter(function(value, index, self) {
    return self.indexOf(value) === index;
  });
  // test print lists for pull down building
  //console.log(cities);
  // console.log(shapes);

  // build pulldown lists
  dates.forEach(function(date) {
    let option = document.createElement("option");
    option.value = date;
    option.innerText = date;
    datetime.append(option);
  });
  shapes.forEach(function(shpe) {
    let option = document.createElement("option");
    option.value = shpe;
    option.innerText = shpe;
    shape.append(option);
  });
  countries.forEach(function(cntry) {
    let option = document.createElement("option");
    option.value = cntry;
    option.innerText = cntry;
    country.append(option);
  });
  states.forEach(function(st) {
    let option = document.createElement("option");
    option.value = st;
    option.innerText = st;
    state.append(option);
  });
  cities.forEach(function(cty) {
    let option = document.createElement("option");
    option.value = cty;
    option.innerText = cty;
    city.append(option);
  });

}


buildFormOptions(data);

//NEED THIS BLOCK????
// data.forEach(function(reportSightings) {
//   // console.log(reportSightings);
//   var row = tbody.append("tr");

//   Object.entries(reportSightings).forEach(function([key, value]){
//     // console.log(key, value);

//     var cell = row.append("td");
//     cell.text(value);
//         });
// });

var filterButton = document.querySelector('#filter-btn');

filterButton.addEventListener('click', function(event) {
  let query = {};
  console.log(query);
  let datetimeValue = datetime.value;
  let shapeValue = shape.value;
  let cntryValue = country.value;
  let stValue = state.value;
  let ctyValue = city.value;

  //console.log(query);

  // console.log("shape value: ", shapeValue);
  // console.log("datetime value: ", datetimeValue);

// SHAPE OF DATA
//     datetime: "1/10/2010",
//     city: "round rock",
//     state: "tx",
//     country: "us",
//     shape: "light",
//     durationMinutes: "2 seconds",
//     comments: "3 Fast-moving lights over Round Rock Texas"


  

  // Build our query
  if(datetimeValue != "default") {
    query.datetime = datetimeValue;
  }
  if(shapeValue != "default") {
    query.shape = shapeValue;
  }
  if(cntryValue != "default") {
    query.country = cntryValue;
  }
  if(stValue != "default") {
    query.state = stValue;
  }
  if(ctyValue != "default") {
    query.city = ctyValue;
  }
  // Repeat for each piece of date you want to filter by. (i.e. country, durationMinutes, etc.)

  // get the date selection value
  // filter data by date value

  console.log(query);

  let dataIndex = 0;
  let queryIndex = 0;
  let queryKeys = Object.keys(query);
  let queryLength = Object.keys(query).length;
  let matches = [...data];

  console.log("before filter: ", matches.length);
  console.log("Data length: ", data.length);

  // let output = [];

  // for (queryIndex; queryIndex < queryLength; queryIndex++) {
  //   if (queryIndex != 0){
  //      matches = output;
  //   }
   
  //   for(dataIndex; dataIndex < matches.length; dataIndex++) {
  //     console.log(dataIndex);
  //     let sighting = matches[dataIndex];
  //     // console.log("sighting", sighting);
  //     let currentQuery = queryKeys[queryIndex];
  //     // console.log("Current query key:", currentQuery);

  //     let sightValue = String(sighting[currentQuery]);
  //     let queryValue = String(query[currentQuery]);
     
  //     if(sightValue === queryValue) {
  //       console.log(`${sightValue} === ${queryValue}`);  
  //       // console.log("got here",sighting[currentQuery]);
  //       output.push(matches[dataIndex]);
      
  //       // let ourMatch = matches.splice(dataIndex, 0);
  //       // console.log("outMatch ", ourMatch);
  //       // output.push(ourMatch);
  //       // console.log("Length of matches is now:", matches.length);
  //     }
  //   console.log("output: ", output);
  //     // console.log(matches);

  //   }
  
  // }

  // Testing this implementation - Zach
  let filteredData = data.filter(function(item) {

    // Filter method loops an array,
    // Compare each item to a condition.
    // If it matches the condition
    // Internally adds to an array.
    // At the end of iteration, returns array of matches

    for (let key in query) {
      if(item[key] === undefined || item[key] != query[key]) {
        // If item doesn't have a key or the ke value doesn't match the query value
        return false;
        // this will filter out the item in question (i.e. sighting.)
      }
    }
    return true; // Moved this outside the for..in loop. it was originally inside the loop which was causing the loop to exit early. - ZSB

  });

  // When I left, this worked. 
  // console.log(filteredData);
  // console.log("after filter: ", filteredData.length);

  // console.log("Total matches: ", matches);
  // console.log("Matches actual: ", matches);


  // let filteredData = data.filter(function(sighting) {
  //   let filterKeys = Object.keys(query);
  //   return filterKeys.every(function(key) {
  //     return query[key].indexOf(sighting[key]);
  //   });
  // });

  // console.log("Original data: ", data.length);
  // console.log("Matches: ", filteredData.length);
  //console.log(filteredData);
  clearTable();
  // renderTable(output);
  renderTable(filteredData);

});


// TODO: Create a function that clears the table.
function clearTable() {
  var tbody = document.querySelector('tbody');
  while(tbody.hasChildNodes()) {
    tbody.removeChild(tbody.firstChild);
  }
}